generatedIntegrationTests = [ "generatedIntegration" ]

eventTestPhasesStart = {phasesToRun ->
  def newPhasesToRun = []
  def unitIdx = phasesToRun.indexOf('unit')
  if(unitIdx != -1) {

    def rootDir = new File(basedir)
    def testDir = new File(rootDir, "test")
    def unitDir = new File(testDir, "unit")

    def integrationDir = new File(testDir, "generatedIntegration")
    if(integrationDir.exists()) ant.delete(dir: integrationDir.path, quiet: true)
    integrationDir.mkdir()

    def runAsIntegration = []
    unitDir.eachFileRecurse{ if(shouldRunAsIntegrationTest(it)) runAsIntegration<< it }

    if(runAsIntegration.size() > 0) {
      phasesToRun.add(unitIdx + 1, "generatedIntegration")

      def unitPath = unitDir.absolutePath
      ant.copy(todir: integrationDir.path) {
        runAsIntegration.each {
           fileset(dir: unitPath, includes: it.absolutePath[unitPath.length()+1..-1])
        }
      }
    }

  }
}

eventTestPhaseStart = {type ->
  if(!"generatedIntegration".equals(type)) return

  System.properties['runningAsIntegrationTest'] = true

  def integrationClassesDir = new File(grailsSettings.testClassesDir, "generatedIntegration")
  if(integrationClassesDir.exists()) ant.delete(dir: integrationClassesDir.path)
}

generatedIntegrationTestsPreparation = {
  def prep = integrationTestsPreparation()
  def generatedIntegrationDir = new File(grailsSettings.testClassesDir, "generatedIntegration")
  def integrationDir = new File(grailsSettings.testClassesDir, "integration")
  ant.copy(todir: generatedIntegrationDir.path) {
     fileset(dir: integrationDir.path)
  }
  prep
}

generatedIntegrationTestsCleanUp = {
  integrationTestsCleanUp()
}

boolean shouldRunAsIntegrationTest(File file) {
  final String property = 'runAsIntegrationTest'
  if(!file.name.endsWith('.groovy') && !file.name.endsWith('.java')) return false
  String content = file.text
  int idx = content.indexOf(property)
  if(idx == -1) return false

  Range typeRange = prevTokenRange(content, idx - 1)
  String type = content[typeRange]
  if(!'boolean'.equals(type) && !'def'.equals(type)) return false

  Range assignmentRange = nextTokenRange(content, idx + property.length())
  def assignment = content[assignmentRange]
  if(!"=".equals(assignment)) return false

  Range valueRange = nextTokenRange(content, assignmentRange[-1] + 1)
  def value = content[valueRange]
  "true".equals(value)
}

Range prevTokenRange(String content, int idx) {
  int endIdx = idx
  while (isWhitespace(content.charAt(endIdx))) {
    endIdx--
  }
  int beginIdx = endIdx
  while (!isWhitespace(content.charAt(beginIdx))) {
    beginIdx--
  }
  beginIdx++
  beginIdx..endIdx
}

Range nextTokenRange(String content, int idx) {
  int beginIdx = idx
  while (isWhitespace(content.charAt(beginIdx))) {
    beginIdx++
  }
  int endIdx = beginIdx
  while (!isWhitespace(content.charAt(endIdx))) {
    endIdx++
  }
  endIdx--
  beginIdx..endIdx
}

boolean isWhitespace(char ch) {
  ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r'
}
