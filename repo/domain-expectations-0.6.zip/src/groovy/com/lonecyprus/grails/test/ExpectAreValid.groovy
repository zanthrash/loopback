package com.lonecyprus.grails.test

/**
 * Copyright 2009 Lone Cyprus Enterprises, LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

public class ExpectAreValid extends ExpectationMatcher {

  String positiveSuffix = "AreValid"
  String negativeSuffix = "AreNotValid"

  public void execute(Object delegate, String method, args) {
    def propertyName = getPropertyName(method)
    Specification spec = new Specification(propertyName: propertyName, delegate: delegate, method: method)
    spec.shouldBeTrue(args.length != 0) { toZeroParametersMessage(spec.readablePropertyName) }
    if (isPositiveMatch(method)) {
      args.each { delegate."expect${spec.getPropertyName()}IsValid"(it) }
    } else {
      if (args.length == 2) {
        delegate."expect${spec.getPropertyName()}IsNotValid"(args[0], args[1])
      } else if (args.length == 1) {
        spec.shouldBeTrue(args[0] instanceof Map) { toOneParameterForAreNotValidMessage(method) }
        args[0].each {k, v -> delegate."expect${spec.getPropertyName()}IsNotValid"(k, v) }
      } else {
        spec.assertTrue toWrongNumberOfParametersForAreNotValidMessage(method), false
      }
    }
  }

  private String toWrongNumberOfParametersForAreNotValidMessage(String method) {
    "The '${method}' expectation requires a value and constraint, a value and constraint list, or a map of any former combination."
  }

  private String toOneParameterForAreNotValidMessage(String method) {
    "When giving one parameter to '${method}', it is expected to be a HashMap with value and constraint or with value and constraint list pairs."
  }

  private String toZeroParametersMessage(String propertyName) {
    "Expected one or many values be given for '${propertyName}' property to test for validity."
  }

}