package com.lonecyprus.grails.test

import com.lonecyprus.grails.test.ConstraintSpecification
import com.lonecyprus.grails.test.ExpectationException
import com.lonecyprus.grails.test.Specification

/**
 * Copyright 2009 Lone Cyprus Enterprises, LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

public abstract class ExpectationMatcher {

  public final static int OPTIONAL = -1

  public boolean isMatch(String method) {
    isPositiveMatch(method) || isNegativeMatch(method)
  }

  protected boolean isPositiveMatch(String method) {
    method =~ /^expect(\w+?)${positiveSuffix}$/
  }

  protected boolean isNegativeMatch(String method) {
    method =~ /^expect(\w+?)${negativeSuffix}$/
  }

  protected boolean isDefaultPolarityMatch(String method) {
    isPositiveMatch(method)
  }

  public void execute(Object delegate, String method, args) {
    def propertyName = getPropertyName(method)
    Specification spec = new Specification(propertyName: propertyName, delegate: delegate, method: method)
    assertHasProperty('constraint')
    assertHasEitherProperty('parameterType', 'parameterTypes')
    assertHasProperty('defaultValue')
    assertHasProperty('positiveSuffix')
    assertHasProperty('negativeSuffix')
    assertHasProperty('accessor')
    execute(spec, method, args)
  }

  public void assertHasEitherProperty(String propertyName1, String propertyName2) {
    if (!hasProperty(propertyName1) && !hasProperty(propertyName2)) {
      throw new ExpectationException("Definition of '${this.class}' is missing property '${propertyName1}' or '${propertyName2}'.\n" +
              "If you are writing your own Expect* class, you will need to provide this property and value " +
              "in order to use the default plugin implementation.")
    }
  }

  public void assertHasProperty(String propertyName) {
    if (!hasProperty(propertyName)) {
      throw new ExpectationException("Definition of '${this.class}' is missing property '${propertyName}.\n" +
              "If you are writing your own Expect* class, you will need to provide this property and value " +
              "in order to use the default plugin implementation.")
    }
  }

  public boolean hasProperty(String propertyName) {
    this.metaClass.hasProperty(this, propertyName)
  }

  public void execute(Specification spec, String method, args) {
    ConstraintSpecification constraintSpec = spec.getConstraint(constraint)
    def declaration = getConstraint(constraintSpec)
    constraintSpec.assertParameterCount(toParameterCount(args.length), args)
    if (hasProperty('types')) constraintSpec.assertTypes(types)
    def expectedValue = (args.length == 1) ? args[0] : toExpectedValue(constraintSpec)
    def expectedParameterType = getParameterType(expectedValue?.class)
    String assertParameterType = getAssertParameterTypeMethod()
    constraintSpec."${assertParameterType}"("expectation", expectedParameterType, expectedValue)
    constraintSpec."${assertParameterType}"("declaration", expectedParameterType, toValue(declaration, defaultValue))
    String assertion = (isDefaultPolarityMatch(method)) ? "expectMatch" : "expectMismatch"
    constraintSpec."${assertion}"(expectedValue, toValue(declaration), defaultValue)
  }

  private int toParameterCount(optionalCount) {
    return hasProperty('parameterCount') ? ((parameterCount <= OPTIONAL) ? optionalCount : parameterCount) : 0
  }

  protected def toExpectedValue(ConstraintSpecification constraintSpec) {
    isDefaultPolarityMatch(constraintSpec.method)
  }

  private String getAssertParameterTypeMethod() {
    return "assertParameterType" + ((hasProperty("parameterTypes")) ? "s" : "")
  }

  private def getParameterType(value) {
    if (hasProperty("parameterTypes") && parameterTypes) return parameterTypes
    if (hasProperty("parameterType") && parameterType) return parameterType
    value
  }

  protected def getConstraint(ConstraintSpecification constraintSpec) {
    constraintSpec.getAppliedConstraint()
  }

  public String getPropertyName(String method) {
    def name = chomp(method, "expect", (isPositiveMatch(method)) ? positiveSuffix : negativeSuffix)
    toPropertyName(name)
  }

  protected String toPropertyName(String name) {
    (name.length()) ? name[0].toLowerCase() + name[1..-1] : ""
  }

  protected String chomp(value, front, back) {
    if ((front.length() + back.length() - value.length()) == 0) return ""
    value[front.length()..-(back.length() + 1)]
  }

  public def toValue(declaration, defaultValue) {
      (toValue(declaration)) ?: defaultValue
  }

  public def toValue(declaration) {
    Eval.x(declaration, "x?.${accessor}")
  }

}
