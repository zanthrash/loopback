package com.lonecyprus.grails.test

/**
 * Copyright 2009 Lone Cyprus Enterprises, LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

public class Specification extends GroovyTestCase {

  def delegate
  String method
  String propertyName

  public ConstraintSpecification getConstraint(constraint) {
    new ConstraintSpecification(
            constraint: constraint,
            delegate: delegate,
            method: method,
            propertyName: getPropertyName())
  }

  public def getType() {
    new DomainInspector(domain: delegate.class).toType(getPropertyName())
  }

  public void assertPropertyExists() {
    assertTrue "Expect that '${delegate.class.name}' has '${getPropertyName()}' declared.", getType() != null
  }

  protected String instanceMessage(String message, value, def ... objects) {
    StringBuilder sb = new StringBuilder()
    sb.append(message)
    sb.append("to be of type ")
    sb.append(objects.collect { "'${(it.class == Class) ? it.name : it}'" }.join(", "))
    sb.append(", but was '${(value == null) ? 'not defined' : (value.class == Class) ? value.name : value.class.name }'.")
    sb.toString()
  }

  public void shouldBeTrue(boolean expect, Closure closure) {
    if (!expect) {
      def value = closure()
      assertTrue value, false
    }
  }

  public void setValue(value) {
    delegate."${getPropertyName()}" = value
  }

  public def getValue() {
    delegate."${getPropertyName()}"
  }

  public String getReadablePropertyName() {
    "${delegate.class.name}.${propertyName}"
  }

  public boolean hasFieldErrors() {
    delegate.errors.hasFieldErrors(propertyName)
  }

  public def getFieldErrors() {
    delegate.errors.getFieldErrors(propertyName)
  }

  public boolean hasErrors() {
    delegate.errors.hasErrors()
  }

  public def getAllErrors() {
    delegate.errors.allErrors
  }

  public boolean isValid() {
    delegate.validate()
  }


  void testShouldDoNothing() {
  }

}

