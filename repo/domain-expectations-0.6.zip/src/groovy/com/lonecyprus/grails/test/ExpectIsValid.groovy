package com.lonecyprus.grails.test

import com.lonecyprus.grails.test.ExpectationException
import com.lonecyprus.grails.test.ExpectationMatcher
import com.lonecyprus.grails.test.Specification
import java.text.MessageFormat

/**
 * Copyright 2009 Lone Cyprus Enterprises, LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

public class ExpectIsValid extends ExpectationMatcher {

  String positiveSuffix = "IsValid"
  String negativeSuffix = "IsNotValid"

  public boolean isPositiveMatch(String method) {
    method =~ /^expect(\w*?)${positiveSuffix}$/
  }

  public boolean isNegativeMatch(String method) {
    method =~ /^expect(\w*?)${negativeSuffix}$/
  }

  public void execute(Object delegate, String method, args) {
    def propertyName = getPropertyName(method)
    Specification spec = new Specification(propertyName: propertyName, delegate: delegate, method: method)
    if (propertyName.length() > 0) {
      if (isPositiveMatch(method)) {
        processPositiveFieldErrors(spec, args)
      } else {
        processNegativeFieldError(spec, args)
      }
    } else {
      if (isPositiveMatch(method)) {
        processAllErrors(spec, args)
      } else {
        throw new ExpectationException("The expectation 'expect${negativeSuffix}' is not supported.")
      }
    }
  }

  private def processNegativeFieldError(Specification spec, args) {
    spec.shouldBeTrue(args.length == 1 || args.length == 2) {
      "Expected the 'invalid value' and the 'constraint(s)' be given for '${spec.readablePropertyName}' property expectation."
    }
    backupExecuteAndRestore(args, spec) {
      boolean isValid = spec.delegate.validate()
      def errors = spec.getFieldErrors()
      def expectedList = toList((args.length == 1) ? args[0] : args[1])
      String message = toUnexpectedConstraintMessage((args.length == 1) ? spec.value : args[0], expectedList, spec, errors)
      spec.shouldBeTrue(!isValid && spec.hasFieldErrors()) { message }
      spec.shouldBeTrue(errors.size() > 0 && errors.size() == expectedList.size()) { message }
      errors.each {error ->
        spec.assertTrue message, expectedList.find { error.code.startsWith(it) } != null
      }
    }
  }

  private List toList(value) {
    return (value instanceof List) ? value : [] << value
  }

  private def processPositiveFieldErrors(Specification spec, args) {
    backupExecuteAndRestore(args, spec) {
      boolean isValid = spec.delegate.validate()
      if (!isValid && spec.hasFieldErrors()) {
        def errors = spec.fieldErrors
        if (errors.size() > 0) {
          StringBuilder sb = new StringBuilder()
          sb.append("The following errors were encountered when validating the '${spec.readablePropertyName}' property:\n")
          errors.each {
            sb.append(java.text.MessageFormat.format(it.defaultMessage, it.arguments))
            sb.append("\n")
          }
          spec.assertTrue sb.toString(), false
        }
      }
    }
  }

  private def processAllErrors(Specification spec, args) {
    if (!spec.isValid() && spec.hasErrors()) {
      def errors = spec.allErrors
      if (errors.size() > 0) {
        StringBuilder sb = new StringBuilder()
        sb.append("The following errors were encountered when validating the '${spec.delegate.class.name}' domain:\n")
        errors.each {
          sb.append(java.text.MessageFormat.format(it.defaultMessage, it.arguments))
          sb.append("\n")
        }
        spec.assertTrue sb.toString(), false
      }
    }

  }

  private String toUnexpectedConstraintMessage(value, expectedList, spec, errors) {
    String prefix = "Expected '${value}' value to break the ${expectedList} constraint on the '${spec.readablePropertyName}' property, but "
    StringBuilder sb = new StringBuilder(prefix)
    def errorList = errors.collect { '"' + it.code + '"' }
    if (errorList.size() == 0) {
      sb.append("none was found.")
    } else {
      sb.append("instead ")
      sb.append(errorList)
      sb.append(" was found.")
    }
    sb.toString()
  }

  private def backupExecuteAndRestore(args, spec, closure) {
    def backup
    try {
      if (shouldBackupAndRestore(spec.method, args)) {
        backup = spec.value
        spec.value = args[0]
      }
      closure()
    } finally {
      if (shouldBackupAndRestore(spec.method, args)) {
        spec.value = backup
      }
    }

  }

  private boolean shouldBackupAndRestore(method, args) {
    return (isPositiveMatch(method) && args.length == 1) ||
            (isNegativeMatch(method) && args.length == 2)
  }

}