package com.lonecyprus.grails.test

import com.lonecyprus.grails.test.Specification
import org.codehaus.groovy.grails.validation.ConstrainedProperty

/**
 * Copyright 2009 Lone Cyprus Enterprises, LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at 
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 */

public class ConstraintSpecification extends Specification {

  String constraint

  public void assertParameterCount(expected, args) {
    shouldBeTrue(expected == args.length) { missingMessage() }
  }

  public void assertType(expected) {
    assertTypes([expected])
  }

  public void assertTypes(List expected) {
    assertTypes(getType(), expected.toArray())
  }

  public void assertTypes(actual, def ... expected) {
    assertTrue typeMessage(actual, expected), isType(actual, expected)
  }

  public boolean isType(actual, def ... expected) {
    expected.find { ("[]".equals(it)) ? actual.isArray() : it.isAssignableFrom(actual) } != null
  }

  protected String missingMessage() {
    "Expected the '${constraint}' constraint to be given for '${readablePropertyName}' property."
  }

  protected String constraintTypeMessage(String kind, value, def ... objects) {
    instanceMessage("Expected the '${constraint}' ${kind} constraint for '${readablePropertyName}' property ", value, objects)
  }

  protected String typeMessage(value, def ... objects) {
    instanceMessage("The '${constraint}' constraint expects the '${readablePropertyName}' property ", value, objects)
  }

  protected String parameterTypeMessage(value, def ... objects) {
    instanceMessage("The '${constraint}' constraint's parameter for the '${readablePropertyName}' property ", value, objects)
  }

  protected String expectMessage(expected, actual) {
    expected = (expected instanceof Closure) ? expected.toString() : expected
    actual = (actual instanceof Closure) ? actual.toString() : actual
    "Expected the '${constraint}' constraint for the '${readablePropertyName}' property to be '${expected}'" +
            ((actual == null) ? "" : ", but was '${actual}'") +
            "."
  }

  protected String expectNotMessage(expected, actual) {
    "Expected the '${constraint}' constraint for the '${readablePropertyName}' property not to be '${expected}'" +
            ((actual == null) ? "" : ", but was '${actual}'") +
            "."
  }

  public void assertParameterType(kind, expected, value) {
    assertParameterTypes(kind, [expected], value)
  }

  public void assertParameterTypes(kind, List expected, value) {
    if ("declaration".equals(kind) && value == null) return
    String message = constraintTypeMessage(kind, value, expected.toArray())
    assertTrue message, expected.find { isParameterType(it, value) } != null || value == null
  }

  public boolean isParameterType(expected, value) {
    if (expected.isPrimitive()) {
      return value != null &&
              value.metaClass.hasProperty(value, 'TYPE') != null &&
              expected.equals(value.TYPE)
    } else {
      return Eval.x(value, "x instanceof ${expected.name}")
    }
  }

  public def getConstraintProperty() {
    boolean hasProperty = delegate.metaClass.hasProperty(delegate, propertyName) != null
    String className = delegate?.class?.name
    String message = "\n\nNo constrained property found for '${className}.${propertyName}'.  This is because you are not :\n" +
            "       Mocking out '${className}' using the Grails Testing Plugin\n" +
            "    OR Running your test as an integration test\n"
    try {
      def value = delegate?.constraints[propertyName]
      shouldBeTrue(value == null || value instanceof ConstrainedProperty) { message }
      value
    } catch (MissingPropertyException e) {
      if (!hasProperty) throw e
      shouldBeTrue(!hasProperty) { message }
    }
  }

  public def getAppliedConstraint() {
    assertPropertyExists()
    getConstraintProperty()?.getAppliedConstraint(constraint)
  }

  public void expectMatch(expected, actual, defaultValue) {
    shouldBeTrue(((actual) ?: defaultValue).equals(expected)) { expectMessage(expected, actual) }
  }

  public void expectMismatch(expected, actual, defaultValue) {
    def value = ((actual) ?: defaultValue)
    if (expected && value && (expected == value)) {
      assertTrue expectNotMessage(expected, actual), false
    }
    if (!expected && value) {
      assertTrue expectMessage(expected, actual), false
    }
  }

  public void expectMismatch(List expected, List actual, defaultValue) {
    boolean areEqual = actual != null && actual.equals(expected)

    if (areEqual) {
      assertFalse expectNotMessage(expected, actual), true
    } else {
      actual.each {
        shouldBeTrue(!expected.contains(it)) { expectNotMessage(expected, actual) }
      }
    }
  }

}