package com.lonecyprus.grails.test

import junit.framework.AssertionFailedError
import com.lonecyprus.grails.test.*

/**
 * Copyright 2009 Lone Cyprus Enterprises, LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

public class Expectations {

  protected static final String STATIC_METHOD_MISSING = '$static_methodMissing'
  protected static final String STATIC_PROPERTY_MISSING = '$static_propertyMissing'
  protected static final String METHOD_MISSING = "methodMissing";
  protected static final String PROPERTY_MISSING = "propertyMissing";

  private static final Class[] METHOD_MISSING_ARGS = [] << String.class << Object.class
  private static final Class[] GETTER_MISSING_ARGS = [] << String.class
  private static final Class[] SETTER_MISSING_ARGS = METHOD_MISSING_ARGS;

  ArrayList<ExpectationMatcher> expectationMatchers = []

  public static applyTo(Class domainClass) {
    new Expectations().addTo(domainClass)
  }

  private String caps(String value) {
    if (!value || value.length() == 0) return ''
    String first = value[0].toUpperCase()
    first + ((value.length() == 1) ? '' : value[1..-1])
  }

  public void addTo(Class domainClass) {

    MetaClass mc = domainClass.metaClass
    MetaMethod oldMethodMissing = mc.getStaticMetaMethod(STATIC_METHOD_MISSING, METHOD_MISSING_ARGS);

    mc.methodMissing = {String name, args ->
      if (isWrittenAsProse(name)) name = 'expect' + name.split(' ').collect { caps(it) }?.join('')

      if (name =~ /^expect.*/) {
        try {
          if (!match(delegate, name, args)) {
            help(findMatchers())
            throw new ExpectationException("Could not find an expectation on '${domainClass.getName()}' which matches '${name}'.")
          }
        } catch (junit.framework.AssertionFailedError e) {
          //e.printStackTrace()
          throw new ExpectationException(e.message)
        }
      } else {
        if (oldMethodMissing) {
          def list = [] << name << args
          return oldMethodMissing.invoke(delegate, list)
        } else {
          throw new MissingMethodException(name, domainClass)
        }
      }

    }

    MetaMethod oldGetterPropertyMissing = mc.getMetaMethod(STATIC_PROPERTY_MISSING, GETTER_MISSING_ARGS)
    mc.propertyMissing = {String name ->
      invokePropertyMissing(domainClass, oldGetterPropertyMissing, delegate, name, [] << name)
    }

    MetaMethod oldSetterPropertyMissing = mc.getMetaMethod(STATIC_PROPERTY_MISSING, SETTER_MISSING_ARGS)
    mc.propertyMissing = {String name, value ->
      invokePropertyMissing(domainClass, oldSetterPropertyMissing, delegate, name, [] << name << value)
    }

  }

  private def invokePropertyMissing(Class domainClass, oldPropertyMissing, delegate, name, args) {
    if (isWrittenAsProse(name)) {
      delegate."${name}"()
    } else {
      if (oldPropertyMissing) {
        oldPropertyMissing.invoke(delegate, list)
      } else {
        throw new MissingPropertyException(name, domainClass)
      }
    }
  }

  private boolean isWrittenAsProse(String method) {
    return !method.startsWith('expect') && method.contains(' ')
  }

  protected boolean match(Object delegate, String method, args) {
    def matchers = findMatchers()
    ExpectationMatcher matcher = matchers.find {it.isMatch(method)}
    matcher?.execute(delegate, method, args)
    return matcher != null
  }

  protected boolean help(matchers) {
    println "DomainExpectations Plugin - version 0.6"
    println "Copyright 2009 Lone Cyprus Enterprises, LLC"
    println "---------------------------------------------"
    println ""

    for (matcher in matchers) {
      println "domain.expect<Property><${matcher.positiveSuffix}|${matcher.negativeSuffix}>()"
    }
    return true
  }

  public void register(ExpectationMatcher expectationMatcher) {
    if (expectationMatchers.size() == 0) init()
    expectationMatchers.add expectationMatcher
  }

  protected void init() {
    expectationMatchers.add new ExpectNullable()
    expectationMatchers.add new ExpectBlank()
    expectationMatchers.add new ExpectMax()
    expectationMatchers.add new ExpectMin()
    expectationMatchers.add new ExpectScale()
    expectationMatchers.add new ExpectMaxSize()
    expectationMatchers.add new ExpectMinSize()
    expectationMatchers.add new ExpectRange()
    expectationMatchers.add new ExpectInList()
    expectationMatchers.add new ExpectMatches()
    expectationMatchers.add new ExpectPassword()
    expectationMatchers.add new ExpectEmail()
    expectationMatchers.add new ExpectUrl()
    expectationMatchers.add new ExpectNotEqual()
    expectationMatchers.add new ExpectCreditCard()
    expectationMatchers.add new ExpectUnique()
    expectationMatchers.add new ExpectValidator()
    expectationMatchers.add new ExpectIsValid()
    expectationMatchers.add new ExpectAreValid()
  }

  protected ArrayList<ExpectationMatcher> findMatchers() {
    if (expectationMatchers.size() == 0) init()
    expectationMatchers
  }

}